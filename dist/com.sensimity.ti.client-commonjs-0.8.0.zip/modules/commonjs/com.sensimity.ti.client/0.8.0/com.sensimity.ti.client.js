(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g=(g.com||(g.com = {}));g=(g.sensimity||(g.sensimity = {}));g=(g.ti||(g.ti = {}));g.client = f()}})(function(){var define,module,exports;return (function e(t,n,r){function o(i,u){if(!n[i]){if(!t[i]){var a=typeof require=="function"&&require;if(!u&&a)return a.length===2?a(i,!0):a(i);if(s&&s.length===2)return s(i,!0);if(s)return s(i);var f=new Error("Cannot find module '"+i+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[i]={exports:{}};t[i][0].call(l.exports,function(e){var n=t[i][1][e];return o(n?n:e)},l,l.exports,e,t,n,r)}return n[i].exports}var i=Array.prototype.slice;Function.prototype.bind||Object.defineProperty(Function.prototype,"bind",{enumerable:!1,configurable:!0,writable:!0,value:function(e){function r(){return t.apply(this instanceof r&&e?this:e,n.concat(i.call(arguments)))}if(typeof this!="function")throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");var t=this,n=i.call(arguments,1);return r.prototype=Object.create(t.prototype),r.prototype.contructor=r,r}});var s=typeof require=="function"&&require;for(var u=0;u<r.length;u++)o(r[u]);return o})({1:[function(require,module,exports){
'use strict';

var sensimity = require('./lib/sensimity');

module.exports = sensimity;

},{"./lib/sensimity":15}],2:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _reste = require('reste');

var _reste2 = _interopRequireDefault(_reste);

var _oauth = require('./oauth2');

var _oauth2 = _interopRequireDefault(_oauth);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var api = new _reste2.default();

var setApiConfig = function setApiConfig() {
  var url = _alloy2.default.CFG.sensimity.url || 'https://api.sensimity.com/';
  api.config({
    debug: false, // allows logging to console of ::REST:: messages
    autoValidateParams: false, // set to true to throw errors if <param> url properties are not passed
    timeout: 10000,
    url: url,
    requestHeaders: {
      Accept: 'application/vnd.sensimity.v1+json',
      'Content-Type': 'application/vnd.sensimity.v1+json',
      Authorization: 'Bearer ' + _oauth2.default.getAccess().token
    },
    methods: [{
      name: 'getNetworks',
      get: 'network'
    }, {
      name: 'getBeacons',
      get: 'network/<networkId>/beacon'
    }, {
      name: 'getBusinessRules',
      get: 'network/<networkId>/business-rule?beacon=<beaconId>'
    }, {
      name: 'getSingleBusinessRule',
      get: 'network/<networkId>/business-rule/<businessRuleId>'
    }, {
      name: 'sendScanResults',
      post: 'scan-results'
    }],
    onLoad: function onLoad(e, callback) {
      return callback(e);
    },
    onError: function onError(e) {
      return Ti.API.info('There was an error accessing the API > ' + JSON.stringify(e));
    }
  });
};

var getNetworks = function getNetworks(callback) {
  return _oauth2.default.init(function () {
    setApiConfig();
    api.getNetworks(function (beacons) {
      return callback(beacons);
    });
  });
};

var getBeacons = function getBeacons(id, callback) {
  return _oauth2.default.init(function () {
    setApiConfig();
    api.getBeacons({ networkId: id }, function (beacons) {
      return callback(beacons);
    });
  });
};

var getBusinessRules = function getBusinessRules(networkId, beaconId, callback) {
  return _oauth2.default.init(function () {
    setApiConfig();
    api.getBusinessRules({
      networkId: networkId,
      beaconId: beaconId
    }, function (response) {
      return callback(response);
    });
  });
};

var getSingleBusinessRule = function getSingleBusinessRule(networkId, businessRuleId, callback) {
  return _oauth2.default.init(function () {
    setApiConfig();
    api.getSingleBusinessRule({
      networkId: networkId,
      businessRuleId: businessRuleId
    }, function (response) {
      return callback(response);
    });
  });
};

var sendScanResults = function sendScanResults(body, callback) {
  return _oauth2.default.init(function () {
    setApiConfig();
    api.sendScanResults({
      body: body
    }, callback);
  });
};

exports.default = {
  getNetworks: getNetworks,
  getBeacons: getBeacons,
  sendScanResults: sendScanResults,
  getSingleBusinessRule: getSingleBusinessRule,
  getBusinessRules: getBusinessRules
};
},{"./oauth2":3,"alloy":undefined,"reste":undefined}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _reste = require('reste');

var _reste2 = _interopRequireDefault(_reste);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var basicAuthHeader = Ti.Utils.base64encode(_alloy2.default.CFG.sensimity.basicHeaderAuthUsername + ':' + _alloy2.default.CFG.sensimity.basicHeaderAuthPassword).toString();
var api = new _reste2.default();
var access = {};

var url = _alloy2.default.CFG.sensimity.url || 'https://api.sensimity.com/';
api.config({
  debug: false, // allows logging to console of ::REST:: messages
  autoValidateParams: false, // set to true to throw errors if <param> url properties are not passed
  timeout: 10000,
  url: url,
  requestHeaders: {
    Accept: 'application/vnd.sensimity.v1+json',
    'Content-Type': 'application/vnd.sensimity.v1+json',
    Authorization: 'Basic ' + basicAuthHeader
  },
  methods: [{ name: 'oauth', post: 'oauth' }],
  onLoad: function onLoad(e, callback) {
    return callback(e);
  }
});

/**
 * Private functions
 */

// Get oauth credentials from storage
var getAuth = function getAuth() {
  return Ti.App.Properties.getObject('sensimity_oauth', {});
};

// Set oauth credentials in storage and update the access variable in memory
var setAuth = function setAuth(object) {
  if (_underscore._.isEmpty(object)) {
    access = {};
  } else {
    access = {
      expires: object.expires,
      token: object.accessToken
    };
  }
  Ti.App.Properties.setObject('sensimity_oauth', object);
};

// Get now
var now = function now() {
  return Math.floor(new Date().getTime() / 1000);
};

// Get access from memory or storage
var getAccess = function getAccess() {
  if (_underscore._.isEmpty(access)) {
    var auth = getAuth();
    if (_underscore._.isEmpty(auth) || _underscore._.isNaN(auth.expires)) {
      return {};
    }
    access = {
      expires: auth.expires,
      token: auth.accessToken
    };
  }

  return access;
};

// Check the expiredate is undefined or is expired
var isAccessTokenExpired = function isAccessTokenExpired() {
  getAccess();
  return _underscore._.isEmpty(access) || now() > access.expires;
};

// check refreshtoken is earlier retrieved
var isRefreshTokenAvailable = function isRefreshTokenAvailable() {
  var auth = getAuth();
  return !_underscore._.isEmpty(auth) && !_underscore._.isUndefined(auth.refreshToken);
};

// Save the obtained token
var saveTokens = function saveTokens(response) {
  var auth = getAuth();
  // Save the retrieved accesstoken
  auth.accessToken = response.access_token;
  if (!_underscore._.isUndefined(response.refresh_token)) {
    // If also an refreshtoken is retrieved, save the refreshtoken
    auth.refreshToken = response.refresh_token;
  }

  // save the time when the accesstoken expires
  auth.expires = now() + response.expires_in;
  setAuth(auth);
};

// Refresh the accesstoken by refreshtoken or password
var refreshAccessToken = function refreshAccessToken(successCallback) {
  var body = {};

  if (isRefreshTokenAvailable()) {
    body.refresh_token = getAuth().refreshToken;
    body.grant_type = 'refresh_token';
  } else {
    body.username = _alloy2.default.CFG.sensimity.username;
    body.password = _alloy2.default.CFG.sensimity.password;
    body.grant_type = 'password';
  }

  api.oauth({ body: body }, function (response) {
    if (response.status) {
      switch (response.status) {
        case 400:
          if (response.title === 'invalid_grant') {
            setAuth({});
            refreshAccessToken(successCallback);
          }
          return;
        default:
          Ti.API.info('Response status is set');
          break;
      }
    }

    saveTokens(response);
    successCallback();
  });
};

/**
 * Initialize the oauthClient, first retrieve the oAuth refreshtoken and trigger the callback.
 * @param Callback you can send a POST or GET request after fetching a new oAuth token
 */
var init = function init(clientReady) {
  return(
    // Check the refreshtoken is expired, if expired retrieve a new accesstoken
    isAccessTokenExpired() ? refreshAccessToken(clientReady) : clientReady()
  );
}; // Set callback

exports.default = {
  init: init,
  getAccess: getAccess
};
},{"alloy":undefined,"alloy/underscore":undefined,"reste":undefined}],4:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _businessRule = require('../service/businessRule');

var _businessRule2 = _interopRequireDefault(_businessRule);

var _knownBeacons = require('../service/knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var foundBeacons = void 0; // Found beacons is used to handle the moving towards and moving away from business rules
var typeOfAvailableBusinessRules = { // Types of available Business rules
  far: 'far',
  close: 'close',
  immediate: 'immediate',
  movingTowards: 'moving_towards',
  movingAwayFrom: 'moving_away_from'
};

var proximities = {
  far: 'far',
  close: 'near',
  immediate: 'immediate'
};

/**
 * Private functions
 */

// Check the proximity of previous beacon has more distance than the new proximity
var checkMovingTowards = function checkMovingTowards(proximity, beaconId) {
  var lastFoundBeacon = _underscore._.findWhere(foundBeacons, {
    beaconId: beaconId,
    proximity: proximities.close
  });
  return !_underscore._.isEmpty(lastFoundBeacon) && (_underscore._.isEqual(proximity, proximities.close) || _underscore._.isEqual(proximity, proximities.immediate));
};

// Check the proximity of previous beacon has less distance than the new proximity
var checkMovingAwayFrom = function checkMovingAwayFrom(proximity, beaconId) {
  var lastFoundImmediateBeacon = _underscore._.findWhere(foundBeacons, {
    beaconId: beaconId,
    proximity: proximities.close
  });
  var lastFoundNearBeacon = _underscore._.findWhere(foundBeacons, {
    beaconId: beaconId,
    proximity: proximities.immediate
  });
  return (!_underscore._.isEmpty(lastFoundNearBeacon) || !_underscore._.isEmpty(lastFoundImmediateBeacon)) && _underscore._.isEqual(proximity, proximities.far);
};

/**
 * Handle and checks beaconproximity and businessrule are the same. If businessrule is active, trigger the dispatcher to use this businessrule in the app
 * @param businessRule
 * @param beacon found Beacon in basescanner
 * @param knownBeacon knownBeacon from local database
 */
var handleBusinessRule = function handleBusinessRule(businessRule, beacon, knownBeacon) {
  var businessRuleType = businessRule.get('type');
  var businessRuleTriggerItem = {
    businessRule: businessRule.toJSON(),
    beacon: beacon,
    knownBeacon: knownBeacon.toJSON()
  };

  if (_underscore._.isEqual(businessRuleType, typeOfAvailableBusinessRules.far) && _underscore._.isEqual(beacon.proximity, proximities.far)) {
    _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:businessrule', businessRuleTriggerItem);
    Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
  }

  if (_underscore._.isEqual(businessRuleType, typeOfAvailableBusinessRules.close) && _underscore._.isEqual(beacon.proximity, proximities.close)) {
    _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:businessrule', businessRuleTriggerItem);
    Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
  }

  if (_underscore._.isEqual(businessRuleType, typeOfAvailableBusinessRules.immediate) && _underscore._.isEqual(beacon.proximity, proximities.immediate)) {
    _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:businessrule', businessRuleTriggerItem);
    Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
  }

  if (_underscore._.isEqual(businessRuleType, typeOfAvailableBusinessRules.movingTowards) && checkMovingTowards(beacon.proximity, knownBeacon.get('beacon_id'))) {
    _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:businessrule', businessRuleTriggerItem);
    Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
  }

  if (_underscore._.isEqual(businessRuleType, typeOfAvailableBusinessRules.movingAwayFrom) && checkMovingAwayFrom(beacon.proximity, knownBeacon.get('beacon_id'))) {
    _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:businessrule', businessRuleTriggerItem);
    Ti.App.fireEvent('sensimity:businessrule', businessRuleTriggerItem);
  }
};

/**
 * Handle a beacon if no businessrule is set for current
 * @param beacon
 * @param knownBeacon
 */
var handleBeacon = function handleBeacon(beacon, knownBeacon) {
  var eventItem = {
    beacon: beacon,
    knownBeacon: knownBeacon.toJSON()
  };
  _alloy2.default.Globals.sensimityDispatcher.trigger('sensimity:beacon', eventItem);
  Ti.App.fireEvent('sensimity:beacon', eventItem);
};

/**
 * Add a found beacon to check moving towards or moving away from
 * @param proximity proximity value to check compare the distance
 * @param beaconId beacon identifier
 */
var addFoundBeacon = function addFoundBeacon(proximity, beaconId) {
  foundBeacons = _underscore._.without(foundBeacons, _underscore._.findWhere(foundBeacons, {
    beaconId: beaconId
  }));
  foundBeacons.push({
    beaconId: beaconId,
    proximity: proximity
  });
};

/**
 * Public functions
 */

/**
 * Initialize the handler and set the notify and knownbeaconservice
 */
var init = function init() {
  foundBeacons = [];
};

/**
 * This function must be called when the beaconscanner founds a beacon. It checks beacon exists in the system and search for the appropiate business rule(s).
 * @param mappedBeacon Mapped beacon is a found beacon in the base scanner
 */
var handle = function handle(mappedBeacon) {
  var knownBeacon = _knownBeacons2.default.findKnownBeacon(mappedBeacon.UUID, mappedBeacon.major, mappedBeacon.minor);
  // If beacon = unknown, do nothing
  if (!_underscore._.isEmpty(knownBeacon)) {
    // Trigger a 'beacon found' event
    handleBeacon(mappedBeacon, knownBeacon);

    // Find appropiate business rules
    var businessRules = _businessRule2.default.getBusinessRules(knownBeacon);

    // Handle every businessrule
    businessRules.forEach(function (businessRule) {
      return handleBusinessRule(businessRule, mappedBeacon, knownBeacon);
    });

    // add found beacon with proximity and beacon_id
    addFoundBeacon(mappedBeacon.proximity, knownBeacon.get('beacon_id'));
  }
};

exports.default = {
  init: init,
  handle: handle
};
},{"../service/businessRule":18,"../service/knownBeacons":19,"alloy":undefined,"alloy/underscore":undefined}],5:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * Public functions
 */

/**
 * A mapping function make the beaconinfo retrieved with the drtech beaconscanner, general
 * @param beaconRaw The beacon retrieved from the altbeacon
 * @returns {{UUID: string, major: Number, minor: Number, rssi: Number, accuracy: Number, proximity: String }}
 */
var map = function map(beaconRaw) {
  return {
    UUID: beaconRaw.uuid.toUpperCase(),
    major: parseInt(beaconRaw.major, 10),
    minor: parseInt(beaconRaw.minor, 10),
    rssi: parseInt(beaconRaw.rssi, 10),
    accuracy: beaconRaw.accuracy,
    proximity: beaconRaw.proximity
  };
};

exports.default = {
  map: map
};
},{}],6:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * A mapping function make the beaconinfo retrieved with the beuckman beaconscanner, general
 * @param beaconRaw The beacon retrieved from the beuckman
 * @returns {{UUID: string, major: Number, minor: Number, rssi: Number, accuracy: Number, proximity: String }}
 */
var map = function map(beaconRaw) {
  return {
    UUID: beaconRaw.uuid.toUpperCase(),
    major: parseInt(beaconRaw.major, 10),
    minor: parseInt(beaconRaw.minor, 10),
    rssi: parseInt(beaconRaw.rssi, 10),
    accuracy: beaconRaw.accuracy,
    proximity: beaconRaw.proximity
  };
};

exports.default = { map: map };
},{}],7:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var map = function map(geofenceRegion) {
  var beaconRaw = geofenceRegion.identifier.split('|');

  return {
    UUID: beaconRaw[1].toUpperCase(),
    major: parseInt(beaconRaw[2], 10),
    minor: parseInt(beaconRaw[3], 10),
    rssi: -1,
    accuracy: -1,
    proximity: -1
  };
};

exports.default = { map: map };
},{}],8:[function(require,module,exports){
'use strict';

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var model = void 0;
var collection = void 0;

exports.definition = {
  config: {
    columns: {
      id: 'INTEGER PRIMARY KEY AUTOINCREMENT',
      beacon_id: 'INTEGER',
      UUID: 'TEXT',
      major: 'INTEGER',
      minor: 'INTEGER',
      rssi: 'INTEGER',
      accuracy: 'INTEGER',
      timestamp: 'INTEGER'
    },
    adapter: {
      db_name: 'sensimity',
      type: 'sql',
      collection_name: 'BeaconLog',
      idAttribute: 'id'
    }
  },
  extendModel: function extendModel(Model) {
    return Model;
  },
  extendCollection: function extendCollection(Collection) {
    _.extend(Collection.prototype, {
      // Extend, override or implement Backbone.Collection
      erase: function erase() {
        var self = this;
        var sql = 'DELETE FROM ' + self.config.adapter.collection_name;
        var db = Ti.Database.open(self.config.adapter.db_name);
        db.execute(sql);
        db.close();

        self.fetch();
      }
    });
    return Collection;
  }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
model = _alloy2.default.M('BeaconLog', exports.definition, [function (migration) {
  // eslint-disable-line
  migration.name = 'BeaconLog';
  migration.id = '20160520094700';
  migration.up = function (migrator) {
    // sqlite has no drop column support
    migrator.dropTable();
    migrator.createTable({
      columns: {
        id: 'INTEGER PRIMARY KEY AUTOINCREMENT',
        beacon_id: 'INTEGER',
        UUID: 'TEXT',
        major: 'INTEGER',
        minor: 'INTEGER',
        rssi: 'INTEGER',
        accuracy: 'INTEGER',
        timestamp: 'INTEGER'
      }
    });
  };
  migration.down = function (migrator) {
    // sqlite has no drop column support
    migrator.dropTable();
    migrator.createTable({
      columns: {
        id: 'INTEGER PRIMARY KEY AUTOINCREMENT',
        UUID: 'TEXT',
        major: 'INTEGER',
        minor: 'INTEGER',
        rssi: 'INTEGER',
        accuracy: 'INTEGER',
        timestamp: 'INTEGER'
      }
    });
  };
}]);

collection = _alloy2.default.C('BeaconLog', exports.definition, model); // eslint-disable-line

exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined}],9:[function(require,module,exports){
'use strict';

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var model = void 0;
var collection = void 0;

exports.definition = {
  config: {
    columns: {
      id: 'INTEGER PRIMARY KEY AUTOINCREMENT',
      business_rule_id: 'INTEGER',
      beacon_id: 'INTEGER',
      type: 'TEXT',
      interaction_id: 'INTEGER',
      interaction_type: 'TEXT',
      content: 'TEXT'
    },
    adapter: {
      db_name: 'sensimity',
      type: 'sql',
      collection_name: 'BusinessRule',
      idAttribute: 'id'
    }
  },
  extendModel: function extendModel(Model) {
    return Model;
  },
  extendCollection: function extendCollection(Collection) {
    _.extend(Collection.prototype, {
      // Extend, override or implement Backbone.Collection
      erase: function erase() {
        var self = this;
        var sql = 'DELETE FROM ' + self.config.adapter.collection_name;
        var db = Ti.Database.open(self.config.adapter.db_name);
        db.execute(sql);
        db.close();

        self.fetch();
      }
    });
    return Collection;
  }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
model = _alloy2.default.M('BusinessRule', exports.definition, []); // eslint-disable-line
collection = _alloy2.default.C('BusinessRule', exports.definition, model); // eslint-disable-line
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined}],10:[function(require,module,exports){
'use strict';

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var model = void 0;
var collection = void 0;

exports.definition = {
  config: {
    columns: {
      id: 'INTEGER',
      beacon_id: 'INTEGER',
      network_id: 'INTEGER',
      title: 'TEXT',
      description: 'TEXT',
      UUID: 'TEXT',
      major: 'INTEGER',
      minor: 'INTEGER',
      latitude: 'REAL',
      longitude: 'REAL',
      is_geofence: 'INTEGER'
    },
    adapter: {
      db_name: 'sensimity',
      type: 'sql',
      collection_name: 'KnownBeacon',
      idAttribute: 'id'
    }
  },
  extendModel: function extendModel(Model) {
    return Model;
  },
  extendCollection: function extendCollection(Collection) {
    _.extend(Collection.prototype, {
      // Extend, override or implement Backbone.Collection
      erase: function erase() {
        var self = this;
        var sql = 'DELETE FROM ' + self.config.adapter.collection_name;
        var db = Ti.Database.open(self.config.adapter.db_name);
        db.execute(sql);
        db.close();

        self.fetch();
      }
    });
    return Collection;
  }
};

// Alloy compiles models automatically to this statement. In this case the models not exists in /app/models folder, so this must be fixed by set this statements manually.
model = _alloy2.default.M('KnownBeacon', exports.definition, []); // eslint-disable-line
collection = _alloy2.default.C('KnownBeacon', exports.definition, model); // eslint-disable-line
exports.Model = model;
exports.Collection = collection;
},{"alloy":undefined}],11:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _BaseScanner2 = require('./BaseScanner');

var _BaseScanner3 = _interopRequireDefault(_BaseScanner2);

var _beacon = require('../mapper/altbeacon/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var AltbeaconScanner = function (_BaseScanner) {
  _inherits(AltbeaconScanner, _BaseScanner);

  function AltbeaconScanner(runInService, beaconLog, beaconHandler) {
    _classCallCheck(this, AltbeaconScanner);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(AltbeaconScanner).call(this, _beacon2.default, beaconLog, beaconHandler));

    _this.Beacons = require('com.drtech.altbeacon');
    _this.scanPeriods = {
      proactive: {
        foregroundScanPeriod: 1101,
        foregroundBetweenScanPeriod: 0,
        backgroundScanPeriod: 5001,
        backgroundBetweenScanPeriod: 60001
      },
      aggressive: {
        foregroundScanPeriod: 1001,
        foregroundBetweenScanPeriod: 0,
        backgroundScanPeriod: 2001,
        backgroundBetweenScanPeriod: 5001
      }
    };
    _this.runInService = runInService;
    _this.beaconFound = _this.beaconFound.bind(_this);
    _this.addAllEventListeners();
    return _this;
  }

  _createClass(AltbeaconScanner, [{
    key: 'bindService',
    value: function bindService(bindCallback) {
      var _this2 = this;

      var handleServiceBind = function handleServiceBind() {
        _this2.Beacons.removeEventListener('serviceBound', handleServiceBind);
        bindCallback();
      };
      this.Beacons.setAutoRange(true);
      this.Beacons.setRunInService(this.runInService);
      this.Beacons.addBeaconLayout('m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24');
      // Start scanning after binding beaconservice
      this.Beacons.addEventListener('serviceBound', handleServiceBind);
      this.Beacons.bindBeaconService();
    }
  }, {
    key: 'startMonitoring',
    value: function startMonitoring(region) {
      this.Beacons.startMonitoringForRegion({
        uuid: region.UUID,
        identifier: region.identifier
      });
    }
  }, {
    key: 'stop',
    value: function stop() {
      if (this.Beacons.beaconServiceIsBound()) {
        this.Beacons.stopMonitoringAllRegions();
        this.Beacons.unbindBeaconService();
      }
    }
  }, {
    key: 'addAllEventListeners',
    value: function addAllEventListeners() {
      this.Beacons.addEventListener('beaconProximity', this.beaconFound);
    }
  }, {
    key: 'removeAllEventListeners',
    value: function removeAllEventListeners() {
      this.Beacons.removeEventListener('beaconProximity', this.beaconFound);
    }
  }, {
    key: 'setBackgroundMode',
    value: function setBackgroundMode(value) {
      this.Beacons.setBackgroundMode(value);
    }
  }, {
    key: 'setBehavior',
    value: function setBehavior(period) {
      if (!_.has(this.scanPeriods, period)) {
        Ti.API.warn('behavior cannot be set. Only values \'proactive\' or \'aggressive\' are applicable');
      }
      this.Beacons.setScanPeriods(this.scanPeriods[period]);
    }
  }]);

  return AltbeaconScanner;
}(_BaseScanner3.default);

exports.default = AltbeaconScanner;
},{"../mapper/altbeacon/beacon":5,"./BaseScanner":12,"com.drtech.altbeacon":undefined}],12:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var BaseScanner = function () {
  function BaseScanner(beaconMapper) {
    var beaconLog = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
    var beaconHandler = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];

    _classCallCheck(this, BaseScanner);

    this.beaconMapper = beaconMapper;
    this.setBeaconLog(beaconLog);
    this.setBeaconHandler(beaconHandler);
  }

  _createClass(BaseScanner, [{
    key: "destruct",
    value: function destruct() {
      this.removeAllEventListeners();
    }
  }, {
    key: "setBeaconLog",
    value: function setBeaconLog(beaconLog) {
      this.beaconLog = beaconLog;
    }
  }, {
    key: "setBeaconHandler",
    value: function setBeaconHandler(beaconHandler) {
      this.beaconHandler = beaconHandler;
    }

    /**
      * Map a found beacon and start the beaconHandler
      * @param beaconRaw A raw beacon found by the beaconscanner
      */

  }, {
    key: "beaconFound",
    value: function beaconFound(beaconRaw) {
      if (_.isUndefined(beaconRaw.rssi) || parseInt(beaconRaw.rssi, 10) === 0) {
        return;
      }

      var beacon = this.beaconMapper.map(beaconRaw);
      this.beaconLog.insertBeaconLog(beacon);
      this.beaconHandler.handle(beacon);
    }
  }]);

  return BaseScanner;
}();

exports.default = BaseScanner;
},{}],13:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _BaseScanner2 = require('./BaseScanner');

var _BaseScanner3 = _interopRequireDefault(_BaseScanner2);

var _beacon = require('../mapper/beuckman/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var BeuckmanScanner = function (_BaseScanner) {
  _inherits(BeuckmanScanner, _BaseScanner);

  function BeuckmanScanner(beaconLog, beaconHandler) {
    _classCallCheck(this, BeuckmanScanner);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(BeuckmanScanner).call(this, _beacon2.default, beaconLog, beaconHandler));

    _this.Beacons = require('org.beuckman.tibeacons');
    _this.beaconRangerHandler = _this.beaconRangerHandler.bind(_this);
    _this.regionState = _this.regionState.bind(_this);
    _this.addAllEventListeners();
    return _this;
  }

  _createClass(BeuckmanScanner, [{
    key: 'startMonitoring',
    value: function startMonitoring(region) {
      this.Beacons.startMonitoringForRegion({
        uuid: region.UUID,
        identifier: region.identifier
      });
    }

    // Start ranging beacons when a beaconregion is detected

  }, {
    key: 'enterRegion',
    value: function enterRegion(param) {
      this.Beacons.startRangingForBeacons(param);
    }

    // Stop ranging beacons for a region when a beaconregion is exited

  }, {
    key: 'exitRegion',
    value: function exitRegion(param) {
      this.Beacons.stopRangingForBeacons(param);
    }

    // Call beaconfound for every found beacon and handle the found beacons

  }, {
    key: 'beaconRangerHandler',
    value: function beaconRangerHandler(param) {
      var _this2 = this;

      param.beacons.forEach(function (beacon) {
        return _this2.beaconFound(beacon);
      });
    }
  }, {
    key: 'regionState',
    value: function regionState(e) {
      if (e.regionState === 'inside') {
        this.Beacons.startRangingForBeacons(_.pick(e, 'uuid', 'identifier'));
      } else if (e.regionState === 'outside') {
        this.Beacons.stopRangingForBeacons(_.pick(e, 'uuid', 'identifier'));
      }
    }
  }, {
    key: 'stop',
    value: function stop() {
      this.Beacons.stopMonitoringAllRegions();
      this.Beacons.stopRangingForAllBeacons();
    }

    // Add eventlisteners, called by startingscan in Basescanner

  }, {
    key: 'addAllEventListeners',
    value: function addAllEventListeners() {
      this.Beacons.addEventListener('beaconRanges', this.beaconRangerHandler);
      this.Beacons.addEventListener('determinedRegionState', this.regionState);
    }
  }, {
    key: 'removeAllEventListeners',
    value: function removeAllEventListeners() {
      this.Beacons.removeEventListener('beaconRanges', this.beaconRangerHandler);
      this.Beacons.removeEventListener('determinedRegionState', this.regionState);
    }
  }]);

  return BeuckmanScanner;
}(_BaseScanner3.default);

exports.default = BeuckmanScanner;
},{"../mapper/beuckman/beacon":6,"./BaseScanner":12,"org.beuckman.tibeacons":undefined}],14:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _comSensimityTi = require('com.sensimity.ti.pathsense');

var _comSensimityTi2 = _interopRequireDefault(_comSensimityTi);

var _beacon = require('../mapper/pathsense/beacon');

var _beacon2 = _interopRequireDefault(_beacon);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Pathsense = function () {
  function Pathsense(beaconHandler) {
    _classCallCheck(this, Pathsense);

    this.beaconHandler = beaconHandler;
    this.enteredRegion = this.enteredRegion.bind(this);
    _comSensimityTi2.default.addEventListener('enteredRegion', this.enteredRegion);
  }

  _createClass(Pathsense, [{
    key: 'enteredRegion',
    value: function enteredRegion(geofenceRegion) {
      var beacon = _beacon2.default.map(geofenceRegion);
      this.beaconHandler.handle(beacon);
    }
  }, {
    key: 'startMonitoring',
    value: function startMonitoring(region) {
      _comSensimityTi2.default.startMonitoringForRegion(region);
    }

    /**
    * Sort geofence-regions by distance inside a defined radius from a predefined location.
    */

  }, {
    key: 'sortRegionsByDistance',
    value: function sortRegionsByDistance(regions, location) {
      var defaultRadius = arguments.length <= 2 || arguments[2] === undefined ? 5000 : arguments[2];

      return _comSensimityTi2.default.sortRegionsByDistance(regions, location, defaultRadius);
    }
  }, {
    key: 'stop',
    value: function stop() {
      _comSensimityTi2.default.stopMonitoringAllRegions();
    }
  }, {
    key: 'destruct',
    value: function destruct() {
      _comSensimityTi2.default.removeEventListener('enteredRegion', this.enteredRegion);
    }
  }]);

  return Pathsense;
}();

exports.default = Pathsense;
},{"../mapper/pathsense/beacon":7,"com.sensimity.ti.pathsense":undefined}],15:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getKnownBeacons = exports.isBLEEnabled = exports.isBLESupported = exports.client = exports.runService = exports.resume = exports.pause = exports.stop = exports.start = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _underscore = require('alloy/underscore');

var _client = require('./client/client');

var _client2 = _interopRequireDefault(_client);

var _knownBeacons = require('./service/knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

var _ScanService = require('./service/ScanService');

var _ScanService2 = _interopRequireDefault(_ScanService);

var _permissions = require('./utils/permissions');

var _dispatcher = require('./utils/dispatcher');

var _dispatcher2 = _interopRequireDefault(_dispatcher);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

if (_underscore._.isUndefined(Alloy.Globals.sensimityDispatcher)) {
  Alloy.Globals.sensimityDispatcher = (0, _dispatcher2.default)();
}

// After refreshing beacons, restart the scanner
var restartScanner = function restartScanner() {
  if (!_underscore._.isUndefined(Alloy.Globals.sensimityScan)) {
    Alloy.Globals.sensimityScan.restart();
  }
};

// Create an scanner, specific for the running platform
var startScanner = function startScanner(options) {
  if (!_underscore._.isUndefined(Alloy.Globals.sensimityScan) || !_underscore._.has(options, 'networkId')) {
    return;
  }

  var scanOptions = options;
  if (Ti.Platform.name === 'android') {
    scanOptions = _extends(options, { runInService: options.runInService || false });
  }

  Alloy.Globals.sensimityScan = new _ScanService2.default(scanOptions);
  Alloy.Globals.sensimityDispatcher.on('sensimity:beaconsRefreshed', restartScanner);
  Alloy.Globals.sensimityScan.start();
};

/**
 * Initialize the scanner and start scanning on added network identifier
 * @param options {network_id: <network identifier to scan beacons>}
 * @param callback Callback to inform about the start of sensimity {success: <bool>, message: <string>}
 */
var start = function start(args, callback) {
  return(
    // Only start Sensimity when bluetooth is enabled
    (0, _permissions.requestLocationPermissions)(function (e) {
      return e.success ? (0, _permissions.isBLEEnabled)(function (isEnabled) {
        var options = _extends({
          requireBLE: true,
          startGeofence: true,
          startBLE: true
        }, args);

        if (!isEnabled && options.requireBLE) {
          var message = 'Sensimity scan not started because BLE not enabled';
          Ti.API.warn(message);
          if (_underscore._.isFunction(callback)) {
            callback({
              success: false,
              message: message
            });
          }
          return;
        }

        startScanner(_extends(options, {
          startBLE: options.startBLE && isEnabled
        }));

        if (_underscore._.isFunction(callback)) {
          callback({
            success: true,
            message: 'Sensimity successfully started'
          });
        }
      }) : function () {
        var message = 'Sensimity scan not started because locationservices are enabled';
        Ti.API.warn(message);
        if (_underscore._.isFunction(callback)) {
          callback({
            success: false,
            message: message
          });
        }
      };
    })
  );
};

/**
 * Stop scanning
 */
var stop = function stop() {
  Alloy.Globals.sensimityDispatcher.off('sensimity:beaconsRefreshed', restartScanner);
  if (!_underscore._.isUndefined(Alloy.Globals.sensimityScan)) {
    Alloy.Globals.sensimityScan.stop();
  }
  Alloy.Globals.sensimityScan = undefined;
};

var pause = function pause() {
  if (Ti.Platform.name !== 'android' || _underscore._.isUndefined(Alloy.Globals.sensimityScan)) {
    return;
  }

  Alloy.Globals.sensimityScan.setBackgroundMode(true);
};

var resume = function resume() {
  if (Ti.Platform.name !== 'android' || _underscore._.isUndefined(Alloy.Globals.sensimityScan)) {
    return;
  }

  Alloy.Globals.sensimityScan.setBackgroundMode(false);
};

/**
 * Start background intent for Android
 * @param callback Callback to inform about the start of sensimity {success: <bool>, message: <string>}
 */
var runService = function runService(options, callback) {
  return(
    // Only start Sensimity when bluetooth is enabled
    (0, _permissions.isBLEEnabled)(function (isEnabled) {
      if (!isEnabled) {
        var message = 'Sensimity scan not started because BLE not enabled';
        Ti.API.warn(message);
        if (_underscore._.isFunction(callback)) {
          callback({
            success: false,
            message: message
          });
        }
        return;
      }

      if (Ti.Platform.name !== 'android' || _underscore._.isUndefined(Alloy.CFG.sensimity.backgroundService)) {
        return;
      }

      var intent = Ti.Android.createServiceIntent({
        url: Alloy.CFG.sensimity.backgroundService,
        startMode: Ti.Android.START_REDELIVER_INTENT
      });

      if (_underscore._.isNumber(options.networkId)) {
        intent.putExtra('networkId', options.networkId);
      }

      if (Ti.Android.isServiceRunning(intent)) {
        Ti.Android.stopService(intent);
      }

      Ti.Android.startService(intent);
      if (_underscore._.isFunction(callback)) {
        callback({
          success: true,
          message: 'Sensimity successfully started in a Android service'
        });
      }
    })
  );
};

var getKnownBeacons = _knownBeacons2.default.getKnownBeacons;
exports.start = start;
exports.stop = stop;
exports.pause = pause;
exports.resume = resume;
exports.runService = runService;
exports.client = _client2.default;
exports.isBLESupported = _permissions.isBLESupported;
exports.isBLEEnabled = _permissions.isBLEEnabled;
exports.getKnownBeacons = getKnownBeacons;
},{"./client/client":2,"./service/ScanService":17,"./service/knownBeacons":19,"./utils/dispatcher":21,"./utils/permissions":22,"alloy/underscore":undefined}],16:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _alloy = require('alloy');

var _alloy2 = _interopRequireDefault(_alloy);

var _underscore = require('alloy/underscore');

var _ti = require('ti.mely');

var _ti2 = _interopRequireDefault(_ti);

var _client = require('../client/client');

var _client2 = _interopRequireDefault(_client);

var _backbone = require('../utils/backbone');

var _knownBeacons = require('./knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var BeaconLog = function () {
  function BeaconLog() {
    _classCallCheck(this, BeaconLog);

    // Send beaconlogs every 30 seconds
    this.timer = _ti2.default.createTimer();
    this.timer.start({
      interval: 30000
    });
    this.sendBeaconLogs = this.sendBeaconLogs.bind(this);
    this.timer.addEventListener('onIntervalChange', this.sendBeaconLogs);
    this.sendBeaconLogs();
  }

  _createClass(BeaconLog, [{
    key: 'sendBeaconLogs',
    value: function sendBeaconLogs() {
      var _this = this;

      if (!Ti.Network.getOnline()) {
        return;
      }

      var sendBeaconLogsAfterFetch = function sendBeaconLogsAfterFetch(beaconLogs) {
        // Send beaconlogs only if exists
        if (beaconLogs.length === 0) {
          return;
        }
        _client2.default.sendScanResults(JSON.parse(JSON.stringify({
          instance_ref: _alloy2.default.CFG.sensimity.instanceRef,
          device: {
            device_id: Ti.Platform.id,
            model: Ti.Platform.model,
            operating_system: Ti.Platform.osname,
            version: Ti.Platform.version
          },
          beaconLogs: beaconLogs
        })), _this.destroyBeaconLogs);
      };

      var library = (0, _backbone.createSensimityCollection)('BeaconLog');
      library.fetch({
        success: sendBeaconLogsAfterFetch });
    }
  }, {
    key: 'insertBeaconLog',
    // eslint-disable-line
    value: function insertBeaconLog(beacon) {
      var timestamp = Math.round(new Date().getTime() / 1000);
      var knownBeacon = _knownBeacons2.default.findKnownBeacon(beacon.UUID, beacon.major, beacon.minor);
      beacon.timestamp = timestamp;
      // If beacon = unknown, do nothing
      if (!_underscore._.isEmpty(knownBeacon)) {
        beacon.beacon_id = knownBeacon.get('beacon_id');
      }
      var beaconLog = (0, _backbone.createSensimityModel)('BeaconLog', beacon);
      beaconLog.save();
    }
  }, {
    key: 'destroyBeaconLogs',
    value: function destroyBeaconLogs() {
      var collection = (0, _backbone.createSensimityCollection)('BeaconLog');
      collection.erase();
    }
  }]);

  return BeaconLog;
}();

exports.default = BeaconLog;
},{"../client/client":2,"../utils/backbone":20,"./knownBeacons":19,"alloy":undefined,"alloy/underscore":undefined,"ti.mely":undefined}],17:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _AltbeaconScanner = require('../scanners/AltbeaconScanner');

var _AltbeaconScanner2 = _interopRequireDefault(_AltbeaconScanner);

var _BeuckmanScanner = require('../scanners/BeuckmanScanner');

var _BeuckmanScanner2 = _interopRequireDefault(_BeuckmanScanner);

var _Pathsense = require('../scanners/Pathsense');

var _Pathsense2 = _interopRequireDefault(_Pathsense);

var _beaconHandler = require('../handlers/beaconHandler');

var _beaconHandler2 = _interopRequireDefault(_beaconHandler);

var _knownBeacons = require('./knownBeacons');

var _knownBeacons2 = _interopRequireDefault(_knownBeacons);

var _BeaconLog = require('./BeaconLog');

var _BeaconLog2 = _interopRequireDefault(_BeaconLog);

var _regions = require('../utils/regions');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var ScanService = function () {
  function ScanService() {
    var options = arguments.length <= 0 || arguments[0] === undefined ? {
      runInService: false,
      hooks: {}
    } : arguments[0];

    _classCallCheck(this, ScanService);

    if (_.isUndefined(options.networkId)) {
      Ti.API.warn('Network identifier is undefined. Can not scan');
      return;
    }

    this.options = options;
    _beaconHandler2.default.init();
    this.beaconLog = new _BeaconLog2.default();
    this.restart = this.restart.bind(this);
    Ti.App.addEventListener('sensimity:hooks:updateRegionsToMonitor', this.restart);

    if (Ti.Platform.name === 'iPhone OS' && Ti.App.arguments.launchOptionsLocationKey) {
      // Do not refresh beacons if the app has been started based on an enter/exited region event
      return;
    }

    _knownBeacons2.default.refreshBeacons([options.networkId]);
  }

  _createClass(ScanService, [{
    key: 'start',
    value: function start() {
      var regions = this.getRegions();
      if (this.options.startBLE && regions.ble.length > 0) {
        this.startBLE(regions.ble);
      }

      if (this.options.startGeofence && regions.geofences.length > 0) {
        this.startGeofence(regions.geofences);
      }
    }
  }, {
    key: 'startBLE',
    value: function startBLE(regions) {
      var scanner = this.getBLEScanner();
      var callback = function callback() {
        return regions.forEach(function (region) {
          return scanner.startMonitoring(region);
        });
      };
      if (_.isFunction(scanner.bindService)) {
        scanner.bindService(callback);
      } else {
        callback();
      }
    }
  }, {
    key: 'startGeofence',
    value: function startGeofence(regions) {
      var scanner = this.getGeofenceScanner();
      var callback = function callback(nearestRegions) {
        return nearestRegions.forEach(function (region) {
          return scanner.startMonitoring(region);
        });
      };

      // geofence-regions are already filtered by the hook, nearest geofences filter not needed
      if (_.isFunction(this.options.hooks.getRegionsToMonitor)) {
        callback(regions);
        return;
      }

      var sortRegionsByDistance = scanner.sortRegionsByDistance;
      (0, _regions.getNearestGeofences)({
        sortRegionsByDistance: sortRegionsByDistance,
        regions: regions,
        callback: callback
      });
    }
  }, {
    key: 'stop',
    value: function stop() {
      if (this.BLEScanner) {
        this.getBLEScanner().stop();
      }
      if (this.geofenceScanner) {
        this.getGeofenceScanner().stop();
      }
    }
  }, {
    key: 'setBackgroundMode',
    value: function setBackgroundMode(bgMode) {
      if (Ti.Platform.name === 'android' && this.BLEScanner) {
        this.BLEScanner.setBackgroundMode(bgMode);
      }
    }
  }, {
    key: 'restart',
    value: function restart() {
      this.stop();
      this.start();
    }
  }, {
    key: 'destruct',
    value: function destruct() {
      this.stop();
      if (this.BLEScanner) {
        this.BLEScanner.destruct();
        this.BLEScanner = undefined;
      }
      if (this.geofenceScanner) {
        this.geofenceScanner.destruct();
        this.geofenceScanner = undefined;
      }
      _beaconHandler2.default.destruct();
      this.beaconLog.destruct();
      this.beaconLog = undefined;
      Ti.App.removeEventListener('sensimity:hooks:updateRegionsToMonitor', this.restart);
    }
  }, {
    key: 'getRegions',
    value: function getRegions() {
      var beacons = _knownBeacons2.default.getKnownBeacons(this.options.networkId);
      if (_.isFunction(this.options.hooks.getRegionsToMonitor)) {
        return (0, _regions.split)(this.options.hooks.getRegionsToMonitor(beacons));
      }
      return (0, _regions.split)(beacons);
    }
  }, {
    key: 'getBLEScanner',
    value: function getBLEScanner() {
      if (Ti.Platform.name === 'iPhone OS') {
        if (!this.BLEScanner) {
          this.BLEScanner = new _BeuckmanScanner2.default(this.beaconLog, _beaconHandler2.default);
        }
      } else if (!this.BLEScanner) {
        this.BLEScanner = new _AltbeaconScanner2.default(this.options.runInService, this.beaconLog, _beaconHandler2.default);
        if (_.has(this.options, 'behavior')) {
          this.BLEScanner.setBehavior(this.options.behavior);
        }
      }

      return this.BLEScanner;
    }
  }, {
    key: 'getGeofenceScanner',
    value: function getGeofenceScanner() {
      if (!this.geofenceScanner) {
        this.geofenceScanner = new _Pathsense2.default(_beaconHandler2.default);
      }
      return this.geofenceScanner;
    }
  }]);

  return ScanService;
}();

exports.default = ScanService;
},{"../handlers/beaconHandler":4,"../scanners/AltbeaconScanner":11,"../scanners/BeuckmanScanner":13,"../scanners/Pathsense":14,"../utils/regions":23,"./BeaconLog":16,"./knownBeacons":19}],18:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _underscore = require('alloy/underscore');

var _client = require('../client/client');

var _client2 = _interopRequireDefault(_client);

var _backbone = require('../utils/backbone');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Create a new businessrule item from the data received from Sensimity
 * @param data The businessrule received from Sensimitys
 * @returns BusinessRule a created businessrule
 */
var createNewBusinessRuleItem = function createNewBusinessRuleItem(data) {
  return (0, _backbone.createSensimityModel)('BusinessRule', {
    business_rule_id: data.business_rule_id,
    beacon_id: data.beacon_id,
    type: data.business_rule_type,
    interaction_id: data.interaction_id,
    interaction_type: data.interaction_type,
    content: data.content
  });
};

/**
 * Set new information retrieved from Sensimity in de Businessrule
 * @param existingBusinessRule The businessrule earlier retrieved from Sensimity
 * @param data The new data
 */
var setNewDataInExistingBusinessRule = function setNewDataInExistingBusinessRule(existingBusinessRule, data) {
  // Override existing business rule
  existingBusinessRule.set('beacon_id', data.beacon_id);
  existingBusinessRule.set('type', data.business_rule_type);
  existingBusinessRule.set('interaction_id', data.interaction_id);
  existingBusinessRule.set('interaction_type', data.interaction_type);
  existingBusinessRule.set('content', data.content);
  return existingBusinessRule;
};

/**
 * Find a business rule based on businessrule Id
 * @param id businessRuleId
 */
var findExistingBusinessRule = function findExistingBusinessRule(businessRuleId) {
  var library = (0, _backbone.createSensimityCollection)('BusinessRule');
  library.fetch();
  var businessRule = library.where({ business_rule_id: businessRuleId });
  if (_underscore._.isEmpty(businessRule)) {
    return businessRule;
  }
  return _underscore._.first(businessRule);
};

/**
 * Function to save all the business rules fetched at the fetchSingleBusinessRule function
 * @param {Object} data retrieved raw business rule data
 */
var saveFetchedBusinessRules = function saveFetchedBusinessRules(data) {
  // Check business rule already exists in the system
  var existingBusinessRule = findExistingBusinessRule(data.business_rule_id);
  var businessRule = void 0;
  if (_underscore._.isEmpty(existingBusinessRule)) {
    // CREATE NEW Business rule
    businessRule = createNewBusinessRuleItem(data);
  } else {
    // Override existing business rule
    businessRule = setNewDataInExistingBusinessRule(existingBusinessRule, data);
  }
  businessRule.save();
};

/**
 * Function to refresh the beacons from Sensimity of a known beacon
 * @param {Object} knownBeacon find the business rules of this beacon
 */
var fetchBusinessRules = function fetchBusinessRules(knownBeacon) {
  return _client2.default.getBusinessRules(knownBeacon.get('network_id'), knownBeacon.get('beacon_id'), function (data) {
    if (!_underscore._.isEmpty(data._embedded.business_rule)) {
      data._embedded.business_rule.forEach(function (businessruleRaw) {
        return saveFetchedBusinessRules(businessruleRaw);
      });
    }
  });
};

/**
 * Function to get all the business rules already saved on the phone
 * @param knownBeacon knownBeacon Get the business rules of this beacon
 */
var getBusinessRules = function getBusinessRules(knownBeacon) {
  var library = (0, _backbone.createSensimityCollection)('BusinessRule');
  library.fetch();
  return library.where({ beacon_id: knownBeacon.get('beacon_id') });
};

exports.default = {
  getBusinessRules: getBusinessRules,
  fetchBusinessRules: fetchBusinessRules
};
},{"../client/client":2,"../utils/backbone":20,"alloy/underscore":undefined}],19:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _underscore = require('alloy/underscore');

var _client = require('../client/client');

var _client2 = _interopRequireDefault(_client);

var _backbone = require('../utils/backbone');

var _businessRule = require('../service/businessRule');

var _businessRule2 = _interopRequireDefault(_businessRule);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Get the beacons earlier retrieved from Sensimity
var getEarlierSavedKnownBeacons = function getEarlierSavedKnownBeacons() {
  var library = (0, _backbone.createSensimityCollection)('KnownBeacon');
  library.fetch();
  return library;
};

var saveBeacon = function saveBeacon(beacon) {
  beacon.UUID = beacon.uuid_beacon.toUpperCase();
  if (!_underscore._.isUndefined(beacon.is_geofence)) {
    beacon.is_geofence = beacon.is_geofence ? 1 : 0;
  } else {
    beacon.is_geofence = 0;
  }
  var sensimityKnownBeacon = (0, _backbone.createSensimityModel)('KnownBeacon', beacon);
  sensimityKnownBeacon.save();
  // Geofences don't contain business rules, so don't fetch them
  if (sensimityKnownBeacon.get('is_geofence')) {
    return;
  }
  // Also refetch all existing business rules
  _businessRule2.default.fetchBusinessRules(sensimityKnownBeacon);
};

// Save all new beacons
var saveNewBeacons = function saveNewBeacons(beaconArray) {
  var library = getEarlierSavedKnownBeacons();
  beaconArray.forEach(function (beacon) {
    // Save only when it is not saved already
    if (library.where(_underscore._.pick(beacon, 'beacon_id')).length === 0) {
      saveBeacon(beacon);
    }
  });
};

// When the beacons successfull received from Sensimity, save local and trigger the whole system to let the system know the beacons refreshed
var handleSuccessfullFetchingBeacons = function handleSuccessfullFetchingBeacons(data) {
  // Handle only fetching if data contains beacons.
  if (!_underscore._.isUndefined(data._embedded) && !_underscore._.isEmpty(data._embedded)) {
    saveNewBeacons(data._embedded.beacon);
    // Let the whole applicatie know that the beacons are refreshed
    Alloy.Globals.sensimityDispatcher.trigger('sensimity:beaconsRefreshed');
  }
};

/**
 * Function to refresh the beacons from Sensimity
 * @param networkIds The network identifiers which must be refreshed
 */
var refreshBeacons = function refreshBeacons(networkIds) {
  if (Ti.Network.getOnline()) {
    _underscore._.uniq(networkIds).forEach(function (id) {
      (0, _backbone.createSensimityCollection)('KnownBeacon').erase();
      _client2.default.getBeacons(id, handleSuccessfullFetchingBeacons);
    });
  }
};

/**
 * Find a beacon based on UUID, major and minor identifier
 * @param String UUID Beacon UUID
 * @param int major Beacon major id
 * @param int minor Beacon minor id
 */
var findKnownBeacon = function findKnownBeacon(UUID, major, minor) {
  return _underscore._.first(getEarlierSavedKnownBeacons().where({
    UUID: UUID,
    major: major,
    minor: minor
  })) || [];
};

/**
 * Retrieve knownbeacons of a network
 * @param networkId The network identifier of the beacons who searching for
 */
var getKnownBeacons = function getKnownBeacons(networkId) {
  return getEarlierSavedKnownBeacons().where({ network_id: networkId });
};

exports.default = {
  refreshBeacons: refreshBeacons,
  findKnownBeacon: findKnownBeacon,
  getKnownBeacons: getKnownBeacons
};
},{"../client/client":2,"../service/businessRule":18,"../utils/backbone":20,"alloy/underscore":undefined}],20:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createSensimityCollection = exports.createSensimityModel = undefined;

var _BeaconLog = require('../models/BeaconLog');

var _BusinessRule = require('../models/BusinessRule');

var _KnownBeacon = require('../models/KnownBeacon');

/**
 * Use an Model defined in the sensimity library
 * @param name The name of the model
 * @param args Arguments for creating a Backbone model
 */
var createSensimityModel = function createSensimityModel(name, args) {
  switch (name) {
    case 'BeaconLog':
      return new _BeaconLog.Model(args);
    case 'BusinessRule':
      return new _BusinessRule.Model(args);
    default:
      return new _KnownBeacon.Model(args);
  }
};

/**
 * Use an Collection defined in the sensimity library
 * @param name The name of the model-collection
 * @param args Arguments for creating a Backbone collection
 */
var createSensimityCollection = function createSensimityCollection(name, args) {
  switch (name) {
    case 'BeaconLog':
      return new _BeaconLog.Collection(args);
    case 'BusinessRule':
      return new _BusinessRule.Collection(args);
    default:
      return new _KnownBeacon.Collection(args);
  }
};

exports.createSensimityModel = createSensimityModel;
exports.createSensimityCollection = createSensimityCollection;
},{"../models/BeaconLog":8,"../models/BusinessRule":9,"../models/KnownBeacon":10}],21:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _backbone = require('alloy/backbone');

var _backbone2 = _interopRequireDefault(_backbone);

var _underscore = require('alloy/underscore');

var _underscore2 = _interopRequireDefault(_underscore);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var dispatcher = function dispatcher() {
  return _underscore2.default.clone(_backbone2.default.Events);
};
exports.default = dispatcher;
},{"alloy/backbone":undefined,"alloy/underscore":undefined}],22:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.requestLocationPermissions = exports.isBLESupported = exports.isBLEEnabled = undefined;

var _dialogs = require('alloy/dialogs');

var _dialogs2 = _interopRequireDefault(_dialogs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var requestLocationPermissions = function requestLocationPermissions(callback) {
  var autorizationType = Ti.Geolocation.AUTHORIZATION_ALWAYS;

  // FIXME: Always returns false on Android 6
  // https://jira.appcelerator.org/browse/TIMOB-23135
  if (Ti.Platform.name === 'iPhone OS' && !Ti.Geolocation.locationServicesEnabled) {
    return callback({
      success: false,
      error: 'Location services disabled'
    });
  }

  if (Ti.Geolocation.hasLocationPermissions(autorizationType)) {
    return callback({
      success: true
    });
  }

  if (Ti.Platform.name === 'iPhone OS') {
    if (Ti.Geolocation.locationServicesAuthorization === Ti.Geolocation.AUTHORIZATION_RESTRICTED) {
      return callback({
        success: false,
        error: 'Your device policy does not allow Geolocation'
      });
    }

    if (Ti.Geolocation.locationServicesAuthorization === Ti.Geolocation.AUTHORIZATION_DENIED) {
      _dialogs2.default.confirm({
        title: 'You denied permission before',
        message: 'Tap Yes to open the Settings app to restore permissions, then try again.',
        callback: function callback() {
          return Ti.Platform.openURL(Ti.App.iOS.applicationOpenSettingsURL);
        }
      });

      // return success:false without an error since we've informed the user already
      return callback({
        success: false
      });
    }
  }

  Ti.Geolocation.requestLocationPermissions(autorizationType, function (e) {
    if (!e.success) {
      return callback({
        success: false,
        error: e.error || 'Failed to request Location Permissions'
      });
    }

    callback({
      success: true
    });
  });
};

var getBLEModule = function getBLEModule() {
  if (Ti.Platform.name === 'android') {
    return require('com.drtech.altbeacon');
  }
  return require('org.beuckman.tibeacons');
};

var isBLESupported = function isBLESupported() {
  return getBLEModule().isBLESupported();
};

var isBLEEnabled = function isBLEEnabled(callback) {
  if (!_.isFunction(callback)) {
    Ti.API.warn('please define a function callback, ble status cannot be retrieved');
    return;
  }

  var BLEModule = getBLEModule();
  if (Ti.Platform.name === 'android') {
    callback(BLEModule.checkAvailability());
    return;
  }

  var handleBleStatus = function handleBleStatus(e) {
    // Useless status See https://github.com/jbeuckm/TiBeacons/issues/24
    if (e.status === 'unknown') {
      return;
    }
    BLEModule.removeEventListener('bluetoothStatus', handleBleStatus);
    callback(e.status === 'on');
  };

  BLEModule.addEventListener('bluetoothStatus', handleBleStatus);
  _.defer(function () {
    return BLEModule.requestBluetoothStatus();
  });
};

exports.isBLEEnabled = isBLEEnabled;
exports.isBLESupported = isBLESupported;
exports.requestLocationPermissions = requestLocationPermissions;
},{"alloy/dialogs":undefined,"com.drtech.altbeacon":undefined,"org.beuckman.tibeacons":undefined}],23:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
var getGeofenceRegions = function getGeofenceRegions(beacons) {
  return _.uniq(beacons.map(function (beacon) {
    return {
      identifier: beacon.get('beacon_id') + '|' + beacon.get('UUID') + '|' + beacon.get('major') + '|' + beacon.get('minor'),
      latitude: beacon.get('latitude'),
      longitude: beacon.get('longitude'),
      radius: 100
    };
  }), false, function (beacon) {
    return beacon.identifier;
  });
};

var getBLERegions = function getBLERegions(beacons) {
  return _.uniq(beacons.map(function (beacon) {
    return {
      identifier: beacon.get('UUID'),
      UUID: beacon.get('UUID')
    };
  }), false, function (beacon) {
    return beacon.identifier;
  });
};

// Use the current position to detect the 20 nearest geofences within 7500 m
var getNearestGeofences = function getNearestGeofences(_ref) {
  var sortRegionsByDistance = _ref.sortRegionsByDistance;
  var regions = _ref.regions;
  var callback = _ref.callback;
  return Ti.Geolocation.getCurrentPosition(function (e) {
    var nearestGeofenceRegions = void 0;
    if (e.success) {
      // Detect only the nearest geofences within 7.5 km
      nearestGeofenceRegions = sortRegionsByDistance(regions, _.pick(e.coords, 'latitude', 'longitude'), 7500);
    }
    callback(_.first(nearestGeofenceRegions || regions, 5));
  });
};

var split = function split(beacons) {
  return {
    ble: getBLERegions(beacons.filter(function (beacon) {
      return !beacon.get('is_geofence');
    })),
    geofences: getGeofenceRegions(beacons.filter(function (beacon) {
      return beacon.get('is_geofence');
    }))
  };
};

exports.split = split;
exports.getNearestGeofences = getNearestGeofences;
},{}]},{},[1])(1)
});